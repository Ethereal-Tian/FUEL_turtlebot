# camera, map, range, path, traj, cmd
# /vins_estimator/camera_pose
rosbag record /planning_vis/frontier /planning_vis/viewpoints /sdf_map/occupancy_local /sdf_map/occupancy_all /planning_vis/trajectory /planning/travel_traj /planning/position_cmd_vis /planning/pos_cmd