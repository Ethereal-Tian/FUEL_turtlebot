#ifndef _LKH_INTERFACE_H
#define _LKH_INTERFACE_H

extern "C" {
#include "LKH.h"
#include "Genetic.h"
}

int solveTSPLKH(const char* input_file);

#endif